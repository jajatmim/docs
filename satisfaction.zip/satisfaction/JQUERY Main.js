$(document).ready(function(){
   $("#emoji li:nth-child(1)").hover(function(){
      $("#dot").css("margin-left","0px");
       function explode(){
           $("#emoji li:nth-child(1) img").attr("src","emoji1.png");
           $("#emoji li:nth-child(2) img").attr("src","emoji22.png");
           $("#emoji li:nth-child(3) img").attr("src","emoji33.png");
           $("#emoji li:nth-child(4) img").attr("src","emoji44.png");
           $("#emoji li:nth-child(5) img").attr("src","emoji55.png");
           $("#note li:nth-child(1)").css("color","white");
           $("#note li:nth-child(2)").css("color","#3A6D88");
           $("#note li:nth-child(3)").css("color","#3A6D88");
           $("#note li:nth-child(4)").css("color","#3A6D88");
           $("#note li:nth-child(5)").css("color","#3A6D88");
       }
       setTimeout(explode,300);
   }); 
    $("#emoji li:nth-child(2)").hover(function(){
      $("#dot").css("margin-left","60px");
       function explode(){
           $("#emoji li:nth-child(1) img").attr("src","emoji11.png");
           $("#emoji li:nth-child(2) img").attr("src","emoji2.png");
           $("#emoji li:nth-child(3) img").attr("src","emoji33.png");
           $("#emoji li:nth-child(4) img").attr("src","emoji44.png");
           $("#emoji li:nth-child(5) img").attr("src","emoji55.png");
           $("#note li:nth-child(1)").css("color","#3A6D88");
           $("#note li:nth-child(2)").css("color","white");
           $("#note li:nth-child(3)").css("color","#3A6D88");
           $("#note li:nth-child(4)").css("color","#3A6D88");
           $("#note li:nth-child(5)").css("color","#3A6D88");
       }
       setTimeout(explode,300);
   });
    $("#emoji li:nth-child(3)").hover(function(){
      $("#dot").css("margin-left","120px");
       function explode(){
           $("#emoji li:nth-child(1) img").attr("src","emoji11.png");
           $("#emoji li:nth-child(2) img").attr("src","emoji22.png");
           $("#emoji li:nth-child(3) img").attr("src","emoji3.png");
           $("#emoji li:nth-child(4) img").attr("src","emoji44.png");
           $("#emoji li:nth-child(5) img").attr("src","emoji55.png");
           $("#note li:nth-child(1)").css("color","#3A6D88");
           $("#note li:nth-child(2)").css("color","#3A6D88");
           $("#note li:nth-child(3)").css("color","white");
           $("#note li:nth-child(4)").css("color","#3A6D88");
           $("#note li:nth-child(5)").css("color","#3A6D88");
       }
       setTimeout(explode,300);
   });
    $("#emoji li:nth-child(4)").hover(function(){
      $("#dot").css("margin-left","180px");
       function explode(){
           $("#emoji li:nth-child(1) img").attr("src","emoji11.png");
           $("#emoji li:nth-child(2) img").attr("src","emoji22.png");
           $("#emoji li:nth-child(3) img").attr("src","emoji33.png");
           $("#emoji li:nth-child(4) img").attr("src","emoji4.png");
           $("#emoji li:nth-child(5) img").attr("src","emoji55.png");
           $("#note li:nth-child(1)").css("color","#3A6D88");
           $("#note li:nth-child(2)").css("color","#3A6D88");
           $("#note li:nth-child(3)").css("color","#3A6D88");
           $("#note li:nth-child(4)").css("color","white");
           $("#note li:nth-child(5)").css("color","#3A6D88");
       }
       setTimeout(explode,300);
   });
    $("#emoji li:nth-child(5)").hover(function(){
      $("#dot").css("margin-left","240px");
       function explode(){
           $("#emoji li:nth-child(1) img").attr("src","emoji11.png");
           $("#emoji li:nth-child(2) img").attr("src","emoji22.png");
           $("#emoji li:nth-child(3) img").attr("src","emoji33.png");
           $("#emoji li:nth-child(4) img").attr("src","emoji44.png");
           $("#emoji li:nth-child(5) img").attr("src","emoji5.png");
           $("#note li:nth-child(1)").css("color","#3A6D88");
           $("#note li:nth-child(2)").css("color","#3A6D88");
           $("#note li:nth-child(3)").css("color","#3A6D88");
           $("#note li:nth-child(4)").css("color","#3A6D88");
           $("#note li:nth-child(5)").css("color","white");
       }
       setTimeout(explode,300);
   });
});